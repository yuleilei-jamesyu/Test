package zhangkang.fourchess;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameView extends SurfaceView implements SurfaceHolder.Callback
{
	private int width, height;
	private TutorialThread myThread;	// �������߳�
	private boolean playerTimeFlag;
	private int[] selectedChessman;	// ��ѡ�������
	private int chessmanSize;	// ���ӿ���
	private int gridSize;		// ���ӿ���
	private int[] basePoint;	// ���������Ͻǵĵ������
	private Chequer chequer;	// ����
	private AI ai;	// AI
	private final int X = 0;	
	private final int Y = 1;
	
	public GameView(Context context, int width, int height)
	{
		super(context);
		getHolder().addCallback(this);
		this.width = width;
		this.height = height;
		playerTimeFlag = true;
		selectedChessman = new int[] {-1, -1};
		chessmanSize = 10;
		gridSize = 80;
		basePoint = new int[] {(this.width - gridSize * 3)/2, (this.width - gridSize * 3)/2};
		chequer = new Chequer();
		ai = new AI(2);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		if(playerTimeFlag)	//�������׶�		
		{
			if(event.getAction() == MotionEvent.ACTION_DOWN)
			{
				if((event.getX() >= basePoint[X] - gridSize && event.getX() <= basePoint[X] + gridSize * 3 + gridSize)
							&& (event.getY() >= basePoint[Y] - gridSize && event.getY() <= basePoint[Y] + gridSize * 3 + gridSize)) // �����������������
				{
					if(getTouchedArea(event.getX(), event.getY())[X] != -1) // ��������������̽���ĵط�
					{
						int[] xy = getTouchedArea(event.getX(), event.getY());
						if(chequer.getValue(xy[X], xy[Y]) == 1)	
						{
							selectedChessman[X] = xy[X];
							selectedChessman[Y] = xy[Y];
						}
						if(chequer.getValue(xy[X], xy[Y]) == 0 && selectedChessman[X] != -1)
						{
							if(chequer.move(selectedChessman[X], selectedChessman[Y], xy[X], xy[Y], 1))
							{
								selectedChessman[X] = -1;	// ���ѡ������
								playerTimeFlag = false;
								myThread.updateCanvas();
								//printLog("Player");
								if(chequer.isWin(2) == 1)
								{	
									myThread.drawYouWin(1);
								}
								else
								{
									playerTimeFlag = false;
									ai.setChequer(chequer);
									int[] movePlan = ai.getMovePlan(chequer, 123);
									chequer.move(movePlan[0], movePlan[1], movePlan[2], movePlan[3], 2);
									myThread.updateCanvas();
									//printLog("AI");
									if(chequer.isWin(1) == 2)
									{	
										myThread.drawYouWin(2);
									}
									playerTimeFlag = true;
								}
							}
						}
					}
				}
			}
		}			
		return super.onTouchEvent(event);
	}
	/*
	private void printLog(String whoPlay)
	{
		Log.v(whoPlay, "-----------------------");
		for(int i = 0; i < 4; i++)
		{	
			String[] text = new String[4];
			for(int j = 0; j < 4; j++)
			{	
				int temp = chequer.getValue(j, i);
				if(temp == 0)
					text[j] = ".";
				if(temp == 1)
					text[j] = "O";
				if(temp == 2)
					text[j] = "X";
			}
			Log.v("PlayArea", text[0] + "\t" + text[1] + "\t" + text[2] + "\t" + text[3]);
		}
	}
	*/
	
	public int[] getTouchedArea(float x, float y)
	{
		
		if(((int)x - basePoint[X] + chessmanSize) % gridSize <= chessmanSize * 2 && ((int)y - basePoint[Y] + chessmanSize) % gridSize <= chessmanSize * 2)
		{
			return new int[] {((int)x - basePoint[X] + chessmanSize) / gridSize, ((int)y - basePoint[Y] + chessmanSize) / gridSize};
		}
		return new int[] {-1, -1};
	}
	
	public void drawBackground(Canvas canvas)
	{
		canvas.drawColor(Color.WHITE);
		Paint paint = new Paint();
		paint.setColor(Color.BLACK);
		//canvas.drawBitmap(background, 0, 0, null);
		canvas.drawLine(basePoint[X], basePoint[Y], basePoint[X] + gridSize * 3, basePoint[Y], paint);
		canvas.drawLine(basePoint[X], basePoint[Y] + gridSize, basePoint[X]  + gridSize * 3, basePoint[Y] + gridSize, paint);
		canvas.drawLine(basePoint[X], basePoint[Y] + gridSize * 2, basePoint[X]  + gridSize * 3, basePoint[Y] + gridSize * 2, paint);
		canvas.drawLine(basePoint[X], basePoint[Y] + gridSize * 3, basePoint[X]  + gridSize * 3, basePoint[Y] + gridSize * 3, paint);
		
		canvas.drawLine(basePoint[X], basePoint[Y], basePoint[X], basePoint[Y] + gridSize * 3, paint);
		canvas.drawLine(basePoint[X] + gridSize, basePoint[Y], basePoint[X] + gridSize, basePoint[Y] + gridSize * 3, paint);
		canvas.drawLine(basePoint[X] + gridSize * 2, basePoint[Y], basePoint[X] + gridSize * 2, basePoint[Y] + gridSize * 3, paint);
		canvas.drawLine(basePoint[X] + gridSize * 3, basePoint[Y], basePoint[X] + gridSize * 3, basePoint[Y] + gridSize * 3, paint);
	}
	
	public void drawChessman(Canvas canvas, int x, int y, int value)
	{
		Paint paint = new Paint();
		switch(value)
		{
			case 1:
			{
				paint.setColor(Color.YELLOW);
				break;
			}
			case 2:
			{
				paint.setColor(Color.RED);
				break;
			}
			case 3:
			{
				paint.setColor(Color.BLUE);
				break;
			}
		}	
		Rect rect = new Rect();
		rect.top = basePoint[Y] + y * gridSize - chessmanSize;
		rect.left = basePoint[X] + x * gridSize - chessmanSize;
		rect.bottom = basePoint[Y] + y * gridSize + chessmanSize;
		rect.right = basePoint[X] + x * gridSize + chessmanSize;
		canvas.drawRect(rect, paint);
	}
	
	public void drawYouWin(Canvas canvas, int value)
	{
		Paint paint = new Paint();
		paint.setColor(Color.BLUE);
		String text = value == 1? "Player Win!" : "AI Win!";
		canvas.drawText(text, 100, height - 100, paint);
	}
	
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) 
	{
		myThread = new TutorialThread(this, getHolder());
		//myThread.setRunningFlag(true);
		myThread.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder hoder) 
	{
		//myThread.setRunningFlag(false);
		boolean retry = true;
		while(retry)
		{
			try
			{
				myThread.join();
				retry = false;
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}	
	}
	
	private class TutorialThread extends Thread
	{
		private GameView gameView;
		private SurfaceHolder surfaceHolder;
		//private boolean runningFlag;
		
		public TutorialThread(GameView gameView, SurfaceHolder surfaceHolder)
		{
			super();
			this.gameView = gameView;
			this.surfaceHolder = surfaceHolder;
			//runningFlag = false;
		}
		
		//public void setRunningFlag(boolean runningFlag)
		//{
		//	this.runningFlag = runningFlag;
		//}
		
		
		//public void updateCanvas(int x1, int y1)
		public void updateCanvas()
		{
			Canvas canvas;
			canvas = null;
			try
			{
				canvas = this.surfaceHolder.lockCanvas();
				synchronized(this.surfaceHolder)
				{
					gameView.drawBackground(canvas);
					for(int y = 0; y < 4; y++)
						for(int x = 0; x < 4; x++)
							if(chequer.getValue(x, y) != 0)
							{	
								gameView.drawChessman(canvas, x, y, chequer.getValue(x, y));
								//Paint paint = new Paint();
								//paint.setColor(Color.BLACK);
								//canvas.drawText("x: " + x1 + ", y: " + y1, 100, 100 , paint);
							}
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				if(canvas != null)
				{
					this.surfaceHolder.unlockCanvasAndPost(canvas);
				}
			}
		}
		
		public void drawYouWin(int value)
		{
			Canvas canvas;
			canvas = null;
			try
			{
				canvas = this.surfaceHolder.lockCanvas();
				synchronized(this.surfaceHolder)
				{
					gameView.drawBackground(canvas);
					for(int y = 0; y < 4; y++)
						for(int x = 0; x < 4; x++)
							if(chequer.getValue(x, y) != 0)
							{	
								gameView.drawChessman(canvas, x, y, chequer.getValue(x, y));
								//Paint paint = new Paint();
								//paint.setColor(Color.BLACK);
								//canvas.drawText("x: " + x1 + ", y: " + y1, 100, 100 , paint);
							}
					gameView.drawYouWin(canvas, value);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				if(canvas != null)
				{
					this.surfaceHolder.unlockCanvasAndPost(canvas);
				}
			}
		}
		
		
		public void run()
		{
			updateCanvas();
		}
	}
}