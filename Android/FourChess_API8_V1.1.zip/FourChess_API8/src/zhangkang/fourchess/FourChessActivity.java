package zhangkang.fourchess;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;

public class FourChessActivity extends Activity {
	Handler myHandler = new Handler(){
		// �Ժ�д
	};
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Full screen.
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
        		WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        int[] size = GetScreenSize();
        this.initGameView(size[0], size[1]);
        //this.initMenuView(size[0], size[1]);
        //setContentView(R.layout.main);
    }

    public void initMenuView(int width, int height)
    {
    	setContentView(new MenuView(this, width, height));
    }

    public void initGameView(int width, int height)
    {
    	setContentView(new GameView(this, width, height));
    }
    
    
    private int[] GetScreenSize()
    {
    	DisplayMetrics dm = new DisplayMetrics();
    	this.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
    	return new int[]{width, height};
    }
}