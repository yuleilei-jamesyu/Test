package zhangkang.fourchess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import android.util.Log;

public class AI 
{
	private int level, value;
	private Chequer chequer;
	private final int EAT = 1;
	private final int LOSE = -1;
	
	public AI(int value)
	{
		this.value = value;
	}

	public void setChequer(Chequer chequer)
	{
		this.chequer = chequer;
	}

	public Chequer getChequer()
	{
		return chequer;
	}
	
	public int[] getMovePlan(Chequer chequer, int level)
	{
		Chequer chequerInThinking = chequer.clone();
		Chequer tempChequer1;
		ArrayList<int[]> myList = chequerInThinking.getAllPossibleMoving(2);	//AI������ı���
		HashMap<int[], Integer> myHashMap = new HashMap<int[], Integer>();
		int maxScore = -100;
		for(int[] aiMovePlan : myList)
		{
			tempChequer1 = chequerInThinking.clone();
			int scoreOfAI = tempChequer1.eat(aiMovePlan[0], aiMovePlan[1], aiMovePlan[2], aiMovePlan[3], 2) * EAT; 
			//Log.v("AI: (" + aiMovePlan[0] +  ", " + aiMovePlan[1] + "), (" + aiMovePlan[2] +  ", " + aiMovePlan[3] + ")", String.valueOf(scoreOfAI));
			int bestMoveOfPlayer = 0;
			if(tempChequer1.isWin(2) == 0)	// AI��ûӮ������������塣
			{
				ArrayList<int[]> playerMoveList = tempChequer1.getAllPossibleMoving(1);
				for(int[] playerMovePlan : playerMoveList)
				{
					Chequer tempChequer2 = tempChequer1.clone();
					int scoreOfPlayer = tempChequer2.eat(playerMovePlan[0], playerMovePlan[1], playerMovePlan[2], playerMovePlan[3], 1) * EAT;
					//Log.v("Player: (" + playerMovePlan[0] +  ", " + playerMovePlan[1] + "), (" + playerMovePlan[2] +  ", " + playerMovePlan[3] + ")", String.valueOf(scoreOfPlayer));
					if(scoreOfPlayer >= bestMoveOfPlayer)
						bestMoveOfPlayer = scoreOfPlayer;
				}	
				//Log.v("Best Move of Player", String.valueOf(bestMoveOfPlayer));
			}	
			int score = scoreOfAI - bestMoveOfPlayer;
			if(score >= maxScore)
				maxScore = score;
			myHashMap.put(aiMovePlan, score);
			
		}
		Iterator<Map.Entry<int[], Integer>> iterator = myHashMap.entrySet().iterator();
		ArrayList<int[]> movePlans = new ArrayList<int[]>();
		while(iterator.hasNext())
		{
			Map.Entry<int[], Integer> entry = (Map.Entry<int[], Integer>)iterator.next();
			if(entry.getValue() == maxScore)
				movePlans.add(entry.getKey());
		}
		int[] movePlan = movePlans.get((int)(Math.random() * movePlans.size()));
		return movePlan;
	}
}
