package zhangkang.fourchess;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class MenuView extends View
{
	//private Bitmap background;
	private int width, height;
	
	public MenuView(Context context, int width, int height)
	{
		super(context);
		initBitmap();
		this.width = width;
		this.height = height;
	}

	@Override
	public void onDraw(Canvas canvas)
	{
		canvas.drawColor(Color.WHITE);
		drawPlayBoard(canvas);
	
	}
	
	private void initBitmap()
	{
		//background = BitmapFactory.decodeResource(this.getResources(), R.drawable.bacnground);
	}

	private void drawPlayBoard(Canvas canvas)
	{
		Paint paint = new Paint();
		paint.setColor(Color.BLACK);
		//canvas.drawBitmap(background, 0, 0, null);
		canvas.drawLine((width - 240)/2, (width - 240)/2, width - (width - 240)/2, (width - 240)/2, paint);
		canvas.drawLine((width - 240)/2, (width - 240)/2 + 80, width - (width - 240)/2, (width - 240)/2 + 80, paint);
		canvas.drawLine((width - 240)/2, (width - 240)/2 + 160, width - (width - 240)/2, (width - 240)/2 + 160, paint);
		canvas.drawLine((width - 240)/2, (width - 240)/2 + 240, width - (width - 240)/2, (width - 240)/2 + 240, paint);
		
		canvas.drawLine((width - 240)/2, (width - 240)/2, (width - 240)/2, (width - 240)/2 + 240, paint);
		canvas.drawLine((width - 240)/2 + 80, (width - 240)/2, (width - 240)/2 + 80, (width - 240)/2 + 240, paint);
		canvas.drawLine((width - 240)/2 + 160, (width - 240)/2, (width - 240)/2 + 160, (width - 240)/2 + 240, paint);
		canvas.drawLine((width - 240)/2 + 240, (width - 240)/2, (width - 240)/2 + 240, (width - 240)/2 + 240, paint);
	}

}