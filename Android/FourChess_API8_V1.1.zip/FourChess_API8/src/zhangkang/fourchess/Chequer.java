package zhangkang.fourchess;

import java.util.ArrayList;


public class Chequer 
{
	private int[][] playArea;
	
	public Chequer()
	{
		playArea = new int[][] {
				{2, 0, 0, 1},
				{2, 0, 0, 1},
				{2, 0, 0, 1},
				{2, 0, 0, 1}
		};
	}

	public Chequer(int[][] playArea)
	{
		this.playArea = playArea;
	}
	
	public Chequer clone()
	{
		return new Chequer(getPlayArea());
	}
	
	private int[][] getPlayArea()
	{
		int[][] playAreaClone = new int[4][4];
		for(int i = 0; i < 4; i++)
			for(int j = 0; j < 4; j++)	
				playAreaClone[i][j] = playArea[i][j];
		return playAreaClone;
	}
	
	public int getValue(int x, int y)
	{
		return playArea[x][y];
	}

	public void setValue(int x, int y, int value)
	{
		playArea[x][y] = value;
	}	

	private boolean canBeMoved(int x, int y, int targetX, int targetY)
	{
		if((targetX < 4 && targetX >= 0) && (targetY < 4 && targetY >= 0))
		{	
			if(((Math.abs(x - targetX) == 1 && y == targetY) 
				||(Math.abs(y - targetY) == 1 && x == targetX)) && playArea[targetX][targetY] == 0)
			{
				return true;
			}
		}
		return false;
	}
	
	public boolean move(int x, int y, int targetX, int targetY, int value)
	{
		if(canBeMoved(x, y, targetX, targetY))
		{
			eat(x, y, targetX, targetY, value);
			return true;
		}
		return false;
	}
	
	public int eat(int x, int y, int targetX, int targetY, int value)
	{
		// ���Եĸ��ӱ���Ϊ3����Ⱦʱ����3����Ⱦ����Ч�����������û�0�����ס�
		int ret = 0;
		int opposedValue = value == 1 ? 2 : 1;
		setValue(targetX, targetY, value);
		setValue(x, y, 0);
		if(targetX == 0)
		{
			if(playArea[1][targetY] == value && playArea[2][targetY] == opposedValue && playArea[3][targetY] == 0)
			{
				ret++;
				playArea[2][targetY] = 0;//3;
			}
		}
		if(targetX == 1)
		{
			if(playArea[0][targetY] == value && playArea[2][targetY] == opposedValue && playArea[3][targetY] == 0)
			{	
				ret++;
				playArea[2][targetY] = 0;//3;
			}
			if(playArea[2][targetY] == value && playArea[0][targetY] == opposedValue && playArea[3][targetY] == 0)
			{
				ret++;
				playArea[0][targetY] = 0;//3;
			}	
			if(playArea[2][targetY] == value && playArea[3][targetY] == opposedValue && playArea[0][targetY] == 0)
			{
				ret++;
				playArea[3][targetY] = 0;//3;
			}		
		}	
		if(targetX == 2)
		{
			if(playArea[3][targetY] == value && playArea[1][targetY] == opposedValue && playArea[0][targetY] == 0)
			{	
				ret++;
				playArea[1][targetY] = 0;//3;
			}
			if(playArea[1][targetY] == value && playArea[0][targetY] == opposedValue && playArea[3][targetY] == 0)
			{
				ret++;
				playArea[0][targetY] = 0;//3;
			}	
			if(playArea[1][targetY] == value && playArea[3][targetY] == opposedValue && playArea[0][targetY] == 0)
			{
				ret++;
				playArea[3][targetY] = 0;//3;
			}			
		}
		if(targetX == 3)
		{
			if(playArea[2][targetY] == value && playArea[1][targetY] == opposedValue && playArea[0][targetY] == 0)
			{
				ret++;
				playArea[1][targetY] = 0;//3;
			}
		}
		if(targetY == 0)
		{
			if(playArea[targetX][1] == value && playArea[targetX][2] == opposedValue && playArea[targetX][3] == 0)
			{
				ret++;
				playArea[targetX][2] = 0;//3;
			}
		}
		if(targetY == 1)
		{
			if(playArea[targetX][0] == value && playArea[targetX][2] == opposedValue && playArea[targetX][3] == 0)
			{	
				ret++;
				playArea[targetX][2] = 0;//3;
			}
			if(playArea[targetX][2] == value && playArea[targetX][0] == opposedValue && playArea[targetX][3] == 0)
			{
				ret++;
				playArea[targetX][0] = 0;//3;
			}	
			if(playArea[targetX][2] == value && playArea[targetX][3] == opposedValue && playArea[targetX][0] == 0)
			{
				ret++;
				playArea[targetX][3] = 0;//3;
			}		
		}	
		if(targetY == 2)
		{
			if(playArea[targetX][3] == value && playArea[targetX][1] == opposedValue && playArea[targetX][0] == 0)
			{	
				ret++;
				playArea[targetX][1] = 0;//3;
			}
			if(playArea[targetX][1] == value && playArea[targetX][0] == opposedValue && playArea[targetX][3] == 0)
			{
				ret++;
				playArea[targetX][0] = 0;//3;
			}	
			if(playArea[targetX][1] == value && playArea[targetX][3] == opposedValue && playArea[targetX][0] == 0)
			{
				ret++;
				playArea[targetX][3] = 0;//3;
			}			
		}
		if(targetY == 3)
		{
			if(playArea[targetX][2] == value && playArea[targetX][1] == opposedValue && playArea[targetX][0] == 0)
			{
				ret++;
				playArea[targetX][1] = 0;//3;
			}
		}		
		return ret;
	}
	
	public ArrayList<int[]> getAllPossibleMoving(int value)
	{
		ArrayList<int[]> myList = new ArrayList<int[]>();
		for(int i = 0; i < 4; i++)
			for(int j = 0; j < 4; j++)
			{
				if(playArea[i][j] == value)
				{
					if(canBeMoved(i, j, i + 1, j))
						myList.add(new int[] {i, j, i + 1, j});
					if(canBeMoved(i, j, i - 1, j))
						myList.add(new int[] {i, j, i - 1, j});
					if(canBeMoved(i, j, i, j + 1))
						myList.add(new int[] {i, j, i, j + 1});
					if(canBeMoved(i, j, i, j - 1))
						myList.add(new int[] {i, j, i, j - 1});
				}
			}
		return myList;
	}
	
	public int isWin(int value)
	{
		if(getAllPossibleMoving(value).size() == 0)
			return value == 1? 2 : 1;
		int playerChessmanCount = 0;
		int aiChessmanCount = 0;
		for(int i = 0; i < 4; i++)
			for(int j = 0; j < 4; j++)
			{
				if(playArea[i][j] == 1)
					playerChessmanCount++;
				if(playArea[i][j] == 2)
					aiChessmanCount++;
			}	
		if(playerChessmanCount == 1)
			return 2;	// AI Win.
		if(aiChessmanCount == 1)
			return 1;	// Player Win.
		return 0;
	}
}
